from PIL import Image

water = "mark.png"
with Image.open(water) as img_water:
    img_water.load()


img_water = Image.open(water)
img_water = img_water.resize((img_water.width // 3, img_water.height // 3))
filename = "image.jpg"
with Image.open(filename) as img:
    img.load()

img.paste(img_water, (450, 400), img_water)
img.save("image_with_mark.jpg")
