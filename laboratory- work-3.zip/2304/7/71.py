from PIL import Image

filename = "image.jpg"
with Image.open(filename) as img:
    img.load()

img.show()
width, height = img.size

print("Ширина: ", width)
print("Высота: ", height)
print("Формат: ", img.format)
print("Цветовая модель:", img.mode)
