from PIL import Image, ImageDraw, ImageFont


name = input("Введите имя получателя: ")
filename = "dr.jpg"
with Image.open(filename) as img:
    img.load()
# используется файл с жирными символами шрифта Arial
font = ImageFont.truetype("bold.ttf", 25)
draw_text = ImageDraw.Draw(img)
draw_text.text(
    (img.width // 2 - 120, 25),
    name + ", поздравляю",
    font=font,
    # fill=('#FAACAC')
)
img.show()
img.save(name + "_postcard.png")
