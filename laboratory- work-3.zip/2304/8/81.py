from PIL import Image

filename = "image.jpg"
with Image.open(filename) as img:
    img.load()

cropped_img = img.crop((500, 1500, 1500, 1700))
# cropped_img.show()
print(img.size)
cropped_img.save("cropped_postcard.jpg")
