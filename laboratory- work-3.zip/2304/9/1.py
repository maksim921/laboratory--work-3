from PIL import Image, ImageFilter
from pathlib import Path

filenames = Path().glob('*')
Path('new_dir').mkdir(parents=True, exist_ok=True)
for file in filenames:
    try:
        with Image.open(file) as img:
            img.load()
            new_img = img.filter(ImageFilter.FIND_EDGES)
            new_img.save(Path("new_dir/" + str(file)))
    except:
        print("Не обработан файл: ", file)